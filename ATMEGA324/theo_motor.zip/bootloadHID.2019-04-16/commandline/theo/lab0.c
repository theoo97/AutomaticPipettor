#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>

#define MAX_SPEED1 10000
#define MAX_DELAY 20000

int16_t speed = 5000;

int main() {
	/* Setăm pinul 0 al portului C ca pin de ieșire. */
	DDRD |= (1 << PD7);

	DDRA |= (1 << PA7) | (1 << PA6) | (1 << PA5) | (1 << PA4);

	PORTD ^= (1 << PD7);

	while(1) {
		
		/* Inversăm starea pinului. */
		/*
		PORTD ^= (1 << PD7);

		_delay_ms(100);
		*/
	
//		int16_t delay_step = MAX_DELAY / speed;	

		const int16_t delay_step = 3;

		if (!(PINB &(1 << PB2)))
		{
			PORTA = (1 << PA7);
			_delay_ms(delay_step);

			PORTA = (1 << PA6);
			_delay_ms(delay_step);


			PORTA = (1 << PA5);
			_delay_ms(delay_step);


			PORTA = (1 << PA4);
			_delay_ms(delay_step);

		}
	}

	return 0;
}
